import React from 'react';
import ReactDOM from 'react-dom';
import Recommends from './components/Recommends.js';

ReactDOM.render(
  React.createElement(Recommends),
  document.getElementById('recommends')
);